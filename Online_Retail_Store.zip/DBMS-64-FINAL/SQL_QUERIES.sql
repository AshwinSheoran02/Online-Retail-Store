

use logintest; 

#Select the Supplier who send the product
#1.
Select Supplier_Name from Supplier Natural Join ( Select Supplier_ID from Supplies where Product_Id = 3) AS S;

#2. Finding the stock of Product when searched using name (using indexing)
CREATE UNIQUE INDEX idxName ON Product ( Name);
 select Stock from product where name = 'Red Local Carrot- 1 kg' ;
  explain select Stock from product where name = 'Red Local Carrot- 1 kg' ;  #searches only one row


#3 . Item in most demand ( item in most carts) most famous
Select name ,  count(Product_ID) as counter from vwatp group by product_ID order by counter desc Limit 1;

#4.
#All the customers who ordered on a particular date
Select F_name , L_name , PhoneNumber from Customer Natural Join (Select PhoneNumber from Receipt where Payment_Date = '2022-04-27'  ) AS R;

#5. Supplier who Supplied the biggest collection of products at a time
Select Supplier_Name from Supplier Where Supplier_ID =  ( Select Supplier_ID from Supplies Where Order_Number = (Select Order_Number from Stock_Order where Quantity = (Select MAX(Quantity) from Stock_Order )   ));




#6. Customers who bought a particular product
SELECT F_name , L_name , PhoneNumber from Customer where PhoneNumber IN ( Select PhoneNumber From cart natural join ( Select cart_id from added_to where product_id = 58 ) AS C  ) ;

#7. FIND NAME AND QUANTITY OF EXPIRED PORDUCTS
Select Name , STOCK , DOE from vwpab where DOE< CURDATE() ;

#8. Most used Payment Type
SELECT payment_Type , Count(Payment_type) as counter from payment group by Payment_Type order by Counter desc ;

#9. Average sale of Last 7 days
SELECT AVG(FINAL_COST) as Average_Sale from receipt where Payment_date <= curdate() And Payment_date > Curdate() - 7;



#10. name of User with maximum purchase in a month
Select F_name , L_name, PhoneNumber from Customer where PhoneNumber in ( Select PhoneNumber from receipt where Final_Cost = ( Select Max(Final_Cost) from receipt ) ) ;


