#insert into product values (1, 30 , 60 , 'Milk' , 'Dairy' , 'Amul' , 'Amul Tonned 1-Litre' , 'B000001' ,'./assets/products/001.jpg' );
#insert into product values (2, 60 , 60 , 'Milk' , 'Dairy' , 'Amul' , 'Amul fullcream 1-Litre' , 'B000001' ,'./assets/products/002.jpg' );
#insert into product values (3, 15 , 60 , 'Milk' , 'Dairy' , 'Amul' , 'Amul Toned half-Litre' , 'B000001' ,'./assets/products/003.jpg' );
insert into product values (4, 15 , 60 , 'Milk' , 'Dairy' , 'Amul' , 'Amul fullcream half-Litre' , 'B000001' ,'./assets/products/004.jpg' );
insert into product values (5, 30 , 60 , 'Milk' , 'Dairy' , 'Amul' , 'Amul DoubleToned 1-Litre' , 'B000001' ,'./assets/products/005.jpg' );
insert into product values (6, 40 , 60 , 'Milk' , 'Dairy' , 'Motherdairy' , 'Mother dairy Toned 1-Litre' , 'B000002' ,'./assets/products/006.jpg' );
insert into product values (7, 36 , 60 , 'Milk' , 'Dairy' , 'Motherdairy' , 'Mother dairy fullcream 1-Litre' , 'B000002' ,'./assets/products/007.jpg' );
insert into product values (8, 30 , 60 , 'Milk' , 'Dairy' , 'Motherdairy' , 'Mother dairy Toned half-Litre' , 'B000002' ,'./assets/products/008.jpg' );
insert into product values (9, 30 , 60 , 'Milk' , 'Dairy' , 'Motherdairy' , 'Mother dairy fullcream half-Litre' , 'B000002' ,'./assets/products/009.jpg' );
insert into product values (10, 40 , 60 , 'Milk' , 'Dairy' , 'Motherdairy' , 'Mother dairy DoubleToned 1-Litre' , 'B000002' ,'./assets/products/010.jpg' );


insert into product values (11, 15 , 60 , 'Milk' , 'Dairy' , 'Amul' , 'Amul DoubleToned half-Litre' , 'B000003' ,'./assets/products/011.jpg' );
insert into product values (12, 20 , 60 , 'Milk' , 'Dairy' , 'Motherdairy' , 'Mother dairy DoubleToned half-Litre' , 'B000002' ,'./assets/products/012.jpg' );
insert into product values (13, 30 , 60 , 'Milk' , 'Dairy' , 'Kwality' , 'Kwality Toned 1-Litre' , 'B000003' ,'./assets/products/013.jpg' );
insert into product values (14, 15 , 60 , 'Milk' , 'Dairy' , 'Kwality' , 'Kwality DoubleToned half-Litre' , 'B000003' ,'./assets/products/014.jpg' );
insert into product values (15, 30 , 60 , 'Milk' , 'Dairy' , 'Kwality' , 'Kwality Toned half-Litre' , 'B000003' ,'./assets/products/015.jpg' );
insert into product values (16, 70 , 30 , 'Paneer' , 'Dairy' , 'Motherdairy' , 'Mother Dairy Paneer - 200 g' , 'B000004' ,'./assets/products/016.jpg' );
insert into product values (17, 77 , 60 , 'Paneer' , 'Dairy' , 'Amul' , 'Amul Paneer - 200 g' , 'B000005' ,'./assets/products/017.jpg' );
insert into product values (18, 250 , 30 , 'Butter' , 'Dairy' , 'Amul' , 'Amul Butter - 500 g - 200 g' , 'B000005' ,'./assets/products/018.jpg' );
insert into product values (19, 100 , 150 , 'Cheese' , 'Dairy' , 'Amul' , 'Amul Cheese Processed - 200 g' , 'B000005' ,'./assets/products/019.jpg' );
insert into product values (20, 250 , 30 , 'Butter' , 'Dairy' , 'Amul' , 'Amul Butter - 100 g' , 'B000006' ,'./assets/products/020.jpg' );




insert into product values (21, 70 , 200 , 'Moong Dal' , 'Pulses' , 'Tata' , 'TATA SAMPANN Moong Dal 1-Kg' , 'B000007' ,'./assets/products/021.jpg' );
insert into product values (22, 120 , 200 , 'Moong Dal' , 'Pulses' , 'Tata' , 'TATA SAMPANN Moong Dal 2-Kg' , 'B000007' ,'./assets/products/022.jpg' );
insert into product values (23, 150 , 200 , 'Moong Dal' , 'Pulses' , 'Tata' , 'TATA SAMPANN Moong Dal Unpolished 1-Kg' , 'B000008' ,'./assets/products/023.jpg' );
insert into product values (24, 250 , 200 , 'Moong Dal' , 'Pulses' , 'Tata' , 'TATA SAMPANN Moong Dal Unpolished 2-Kg' , 'B000008' ,'./assets/products/024.jpg' );
insert into product values (25, 700 , 200 , 'Moong Dal' , 'Pulses' , 'Tata' , 'TATA SAMPANN Moong Dal Chilka 1-Kg' , 'B000009' ,'./assets/products/025.jpg' );
insert into product values (26, 120 , 200 , 'Moong Dal' , 'Pulses' , 'Tata' , 'TATA SAMPANN Moong Dal Chilka 2-Kg' , 'B000009' ,'./assets/products/026.jpg' );
insert into product values (27, 130 , 200 , 'Moong Dal' , 'Pulses' , 'Tata' , 'TATA SAMPANN Moong Dal Chilka Unpolished 1-Kg' , 'B000010' ,'./assets/products/027.jpg' );
insert into product values (28, 240 , 200 , 'Moong Dal' , 'Pulses' , 'Tata' , 'TATA SAMPANN Moong Dal Chilka Unpolished 2-Kg' , 'B000010' ,'./assets/products/028.jpg' );
insert into product values (29, 130 , 200 , 'Moong Dal' , 'Pulses' , 'Rajdhani' , 'RAJDHANI Moong Dal Chilka 2-Kg' , 'B000011' ,'./assets/products/029.jpg' );
insert into product values (30, 200 , 200 , 'Moong Dal' , 'Pulses' , 'Rajdhani' , 'RAJDHANI Moong Dal Chilka Unpolished 2-Kg' , 'B000012' ,'./assets/products/030.jpg' );




insert into product values (31, 180 , 150 , 'Rajma' , 'Pulses', 'Harvest' ,'Rajma jammu 1-Kg' , 'B000012' ,'./assets/products/031.jpg' );
insert into product values (32, 350 , 150 , 'Rajma' , 'Pulses', 'Harvest' ,'Rajma jammu 2-Kg' , 'B000012' ,'./assets/products/032.jpg' );
insert into product values (33, 800 , 150 , 'Rajma' , 'Pulses', 'Harvest' ,'Rajma jammu 5-Kg' , 'B000012' ,'./assets/products/033.jpg' );
insert into product values (34, 200 , 150 , 'Rajma' , 'Pulses', 'Tata' ,'TATA SAMPANN Rajma jammu 1-Kg' , 'B000013' ,'./assets/products/034.jpg' );
insert into product values (35, 380 , 150 , 'Rajma' , 'Pulses', 'Tata' ,'TATA SAMPANN Rajma jammu 2-Kg' , 'B000013' ,'./assets/products/035.jpg' );
insert into product values (36, 900 , 150 , 'Rajma' , 'Pulses', 'Tata' ,'TATA SAMPANN Rajma jammu 5-Kg' , 'B000013' ,'./assets/products/036.jpg' );
insert into product values (37, 80 , 150 , 'Rajma' , 'Pulses', 'Tata' ,'TATA SAMPANN Red Rajma 1-Kg' , 'B000014' ,'./assets/products/037.jpg' );
insert into product values (38, 100 , 150 , 'Rajma' , 'Pulses', 'Harvest' ,'Red Rajma 1-Kg' , 'B000015' ,'./assets/products/038.jpg' );
insert into product values (39, 190 , 150 , 'Rajma' , 'Pulses', 'Harvest' ,'Red Rajma 2-Kg' , 'B000015' ,'./assets/products/039.jpg' );
insert into product values (40, 420 , 150 , 'Rajma' , 'Pulses', 'Organic Tattva' ,'ORGANIC TATTVA Chitra Rajma 2-Kg' , 'B000016' ,'./assets/products/040.jpg' );



insert into product values (41, 60 , 250 , 'Wheat' , 'Grains', 'Fortune' ,'Fortune Chakki Fresh Atta 1-kg' , 'B000018' ,'./assets/products/041.jpg' );
insert into product values (42, 1500 , 250 , 'Wheat' , 'Grains', 'Fortune' ,'Fortune Chakki Fresh Atta 2-kg' , 'B000018' ,'./assets/products/042.jpg' );
insert into product values (43, 300 , 250 , 'Wheat' , 'Grains', 'Fortune' ,'Fortune Chakki Fresh Atta 5-kg' , 'B000018' ,'./assets/products/043.jpg' );
insert into product values (44, 100 , 250 , 'Wheat' , 'Grains', 'Aashirvaad' ,'Aashirvaad Shudh Chakki Atta 2-kg' , 'B000019' ,'./assets/products/044.jpg' );
insert into product values (45, 250 , 250 , 'Wheat' , 'Grains', 'Aashirvaad' ,'Aashirvaad Shudh Chakki Atta 5-kg' , 'B000019' ,'./assets/products/045.jpg' );
insert into product values (46, 500 , 250 , 'Wheat' , 'Grains', 'Aashirvaad' ,'Aashirvaad Shudh Chakki Atta 10-kg' , 'B000019' ,'./assets/products/046.jpg' );
insert into product values (47, 100 , 250 , 'Wheat' , 'Grains', 'Aashirvaad' ,'Aashirvaad Select Premium Sharbati Atta 2-kg' , 'B000020' ,'./assets/products/047.jpg' );
insert into product values (48, 250 , 250 , 'Wheat' , 'Grains', 'Aashirvaad' ,'Aashirvaad Select Premium Sharbati Atta 5-kg' , 'B000020' ,'./assets/products/048.jpg' );
insert into product values (49, 500 , 250 , 'Wheat' , 'Grains', 'Aashirvaad' ,'Aashirvaad Select Premium Sharbati Atta 10-kg' , 'B000020' ,'./assets/products/049.jpg' );
insert into product values (50, 280 , 250 , 'Wheat' , 'Grains', 'Aashirvaad' ,'Aashirvaad Atta with Multigrains-5kg' , 'B000021' ,'./assets/products/050.jpg' );




insert into product values (51, 49 , 100 , 'Grapes' , 'Fruits', 'Big Bazaar' ,'Fresh Grapes Sonaka Seedless- 500g' , 'B000023' ,'./assets/products/051.jpg' );
insert into product values (52, 79 , 100 , 'Grapes' , 'Fruits', 'Big Bazaar' ,'Fresh Oranges Nagpur- 1 kg' , 'B000024' ,'./assets/products/052.jpg' );
insert into product values (53, 44 , 100 , 'Grapes' , 'Fruits', 'Big Bazaar' ,'Bananas Robusto- 1 kg' , 'B000022' ,'./assets/products/053.jpg' );
insert into product values (54, 180 , 100 , 'Grapes' , 'Fruits', 'Big Bazaar' ,'Apple Red Delicious - 4 Nos' , 'B000017' ,'./assets/products/054.jpg' );
insert into product values (55, 150 , 100 , 'Grapes' , 'Fruits', 'Big Bazaar' ,'Pomegranate - 4 Nos' , 'B000025' ,'./assets/products/055.jpg' );
insert into product values (56, 98 , 100 , 'Grapes' , 'Fruits', 'Big Bazaar' ,'Apple Kashmir - 4 Nos' , 'B000017' ,'./assets/products/056.jpg' );
insert into product values (57, 100 , 100 , 'Grapes' , 'Fruits', 'Big Bazaar' ,'Apple Kinnaur - 4 Nos' , 'B000017' ,'./assets/products/057.jpg' );
insert into product values (58, 44 , 100 , 'Grapes' , 'Fruits', 'Big Bazaar' ,'Ber - 500 g' , 'B000027' ,'./assets/products/058.jpg' );
insert into product values (59, 89 , 100 , 'Grapes' , 'Fruits', 'Big Bazaar' ,'Pineapple - 1 Nos' , 'B000028' ,'./assets/products/059.jpg' );
insert into product values (60, 180 , 100 , 'Grapes' , 'Fruits', 'Big Bazaar' ,'Grapes Red Globe Indian- 500g' , 'B000023' ,'./assets/products/060.jpg' );




insert into product values (61, 25 , 350 , 'Carrots' , 'Vegetables', 'Big Bazaar' ,'Red Local Carrot- 1 kg' , 'B000029' ,'./assets/products/061.jpg' );
insert into product values (62, 25 , 350 , 'Cauliflower' , 'Vegetables', 'Big Bazaar' ,'Cauliflower - 1 Nos' , 'B000030' ,'./assets/products/062.jpg' );
insert into product values (63, 10 , 350 , 'Corriander' , 'Vegetables', 'Big Bazaar' ,'Corriander- 100 g' , 'B000031' ,'./assets/products/063.jpg' );
insert into product values (64, 42 , 350 , 'Onion' , 'Vegetables', 'Big Bazaar' ,'Onion - 1 kg' , 'B000032' ,'./assets/products/064.jpg' );
insert into product values (65, 39 , 350 , 'Tomato' , 'Vegetables', 'Big Bazaar' ,'Tomato Hybrid- 1 kg' , 'B000033' ,'./assets/products/065.jpg' );
insert into product values (66, 10 , 350 , 'Spinach' , 'Vegetables', 'Big Bazaar' ,'Spinach- 250 g' , 'B000034' ,'./assets/products/066.jpg' );
insert into product values (67, 20 , 350 , 'Cabbage' , 'Vegetables', 'Big Bazaar' ,'Cabbage- 1 Nos 400g to 700g' , 'B000029' ,'./assets/products/067.jpg' );
insert into product values (68, 16 , 350 , 'Potato' , 'Vegetables', 'Big Bazaar' ,'Potato- 1 kg' , 'B000030' ,'./assets/products/068.jpg' );
insert into product values (69, 12 , 350 , 'Green Chilli' , 'Vegetables', 'Big Bazaar' ,'Green Chilli - 100 g' , 'B000031' ,'./assets/products/069.jpg' );
insert into product values (70, 47 , 350 , 'Capsicum' , 'Vegetables', 'Big Bazaar' ,'Red Local Carrot- 2 kg' , 'B000032' ,'./assets/products/070.jpg' );




insert into product values (71, 200 , 250 , 'Rice' , 'Grains', 'India Gate' ,'India Gate Basmati Rice Classic - 1 kg' , 'B000035' ,'./assets/products/071.jpg' );
insert into product values (72, 400 , 250 , 'Rice' , 'Grains', 'India Gate' ,'India Gate Basmati Rice Classic - 2 kg' , 'B000035' ,'./assets/products/072.jpg' );
insert into product values (73, 1000 , 250 , 'Rice' , 'Grains', 'India Gate' ,'India Gate Basmati Rice Classic - 5 kg' , 'B000035' ,'./assets/products/073.jpg' );
insert into product values (74, 800 , 250 , 'Rice' , 'Grains', 'Fortune' ,'Fortune Rozana Basmati Rice - 1 kg' , 'B000036' ,'./assets/products/074.jpg' );
insert into product values (75, 200 , 250 , 'Rice' , 'Grains', 'Fortune' ,'Fortune Rozana Basmati Rice - 2 kg' , 'B000036' ,'./assets/products/075.jpg' );
insert into product values (76, 500 , 250 , 'Rice' , 'Grains', 'Fortune' ,'Fortune Rozana Basmati Rice - 5 kg' , 'B000036' ,'./assets/products/076.jpg' );
insert into product values (77, 90 , 250 , 'Rice' , 'Grains', 'India Gate' ,'India Gate Basmati Rice Rozana - 1 kg' , 'B000037' ,'./assets/products/077.jpg' );
insert into product values (78, 170 , 250 , 'Rice' , 'Grains', 'India Gate' ,'India Gate Basmati Rice Rozana - 2 kg' , 'B000037' ,'./assets/products/078.jpg' );
insert into product values (79, 495 , 250 , 'Rice' , 'Grains', 'India Gate' ,'India Gate Basmati Rice Rozana - 5 kg' , 'B000037' ,'./assets/products/079.jpg' );
insert into product values (80, 390 , 250 , 'Rice' , 'Grains', 'Daawat' ,'Daawat Basmati Rice Rozana - 5 kg' , 'B000038' ,'./assets/products/080.jpg' );




insert into product values (81, 16 , 250 , 'Chips' , 'Snacks', 'Lays' ,'Lays American Style Potato Chips Cream & Onion - 52g' , 'B000039' ,'./assets/products/081.jpg' );
insert into product values (82, 45 , 250 , 'Chips' , 'Snacks', 'Lays' ,'Lays Potato Chips Masala Magic -130gm' , 'B000039' ,'./assets/products/082.jpg' );
insert into product values (83, 45 , 250 , 'Chips' , 'Snacks', 'Doritos' ,'Doritos Nacho Cheese Flavour, 100 gm' , 'B000040' ,'./assets/products/083.jpg' );
insert into product values (84, 40 , 250 , 'Chips' , 'Snacks', 'Bingo' ,'Bingo! Original Style Chilli Sprinkled -100g' , 'B000041' ,'./assets/products/084.jpg' );
insert into product values (85, 18 , 250 , 'Chips' , 'Snacks', 'Bingo' ,'Bingo! Mad Angle Very Peri Peri - 66g' , 'B000041' ,'./assets/products/085.jpg' );
insert into product values (86, 20 , 250 , 'Chips' , 'Snacks', 'Lays' ,'Lays Maxx Macho Chili Flavour - 130g' , 'B000039' ,'./assets/products/086.jpg' );
insert into product values (87, 20 , 250 , 'Chips' , 'Snacks', 'Lays' ,'Lays Maxx Barbeque Flavour - 130g' , 'B000039' ,'./assets/products/087.jpg' );
insert into product values (88, 20 , 250 , 'Chips' , 'Snacks', 'Lays' ,'Lays Maxx Sizzling Barbeque - 130g' , 'B000039' ,'./assets/products/088.jpg' );
insert into product values (89, 170 , 250 , 'Chips' , 'Snacks', 'Jolo' ,'Jolo Chip Last Chip Challenge - 52g' , 'B000042' ,'./assets/products/089.jpg' );
insert into product values (90, 90 , 250 , 'Chips' , 'Snacks', 'Pringals' ,'Pringles Potato Chips Original' , 'B000043' ,'./assets/products/090.jpg' );




insert into product values (91, 90 , 200 , 'Carbonated-Drinks' , 'Soft-Drinks', 'Coca-Cola' ,'Coca-Cola Soft Drink - 2.25 L' , 'B000044' ,'./assets/products/091.jpg' );
insert into product values (92, 38 , 200 , 'Carbonated-Drinks' , 'Soft-Drinks', 'Coca-Cola' ,'Coca-Cola Zero Soft Drink Can -  300 ml' , 'B000044' ,'./assets/products/092.jpg' );
insert into product values (93, 30 , 200 , 'Carbonated-Drinks' , 'Soft-Drinks', 'Coca-Cola' ,'Coca-Cola - 750 ml' , 'B000044' ,'./assets/products/093.jpg' );
insert into product values (94, 80 , 200 , 'Carbonated-Drinks' , 'Soft-Drinks', 'Red Bull' ,'Red Bull Energy Drink - 250 m' , 'B000045' ,'./assets/products/094.jpg' );
insert into product values (95, 30 , 200 , 'Carbonated-Drinks' , 'Soft-Drinks', 'Fanta' ,'Fanta Orange Flavoured Soft Drink - 300 ml' , 'B000045' ,'./assets/products/095.jpg' );
insert into product values (96, 110 , 200 , 'Fruit-Drinks' , 'Soft-Drinks', 'Real' ,'Real Fruit Power Mixed Fruit - 1L' , 'B000046' ,'./assets/products/096.jpg' );
insert into product values (97, 10 , 200 , 'Fruit-Drinks' , 'Soft-Drinks', 'Maaza' ,'Maaza Mango Fruit Drink - 150 ml' , 'B000047' ,'./assets/products/097.jpg' );
insert into product values (98, 10 , 200 , 'Fruit-Drinks' , 'Soft-Drinks', 'Frooti' ,'Frooti Mango Tetra - 150 ml' , 'B000048' ,'./assets/products/098.jpg' );
insert into product values (99, 50 , 200 , 'Fruit-Drinks' , 'Soft-Drinks', 'Tropicana' ,'Tropicana Slice Mango Jiuce - 1.2 L' , 'B000049' ,'./assets/products/099.jpg' );
insert into product values (100, 70 , 200 , 'Fruit-Drinks' , 'Soft-Drinks', 'Frooti' ,'Frooti Pet Bottle - 1.2 L' , 'B000048' ,'./assets/products/100.jpg' );




insert into product values (101, 84999 , 11 , 'Smartphones' , 'Electronics', 'Apple' ,'Apple iPhone 13 256GB - Starlight' , 'B000050' ,'./assets/products/101.jpg' );
insert into product values (102, 69999 , 14 , 'Smartphones' , 'Electronics', 'Apple' ,'Apple iPhone 13 Mini 128GB - Blue' , 'B000051' ,'./assets/products/102.jpg' );
insert into product values (103, 139999 , 14 , 'Smartphones' , 'Electronics', 'Apple' ,'Apple iPhone 13 Pro Max 256GB - Sierra Blue' , 'B000052' ,'./assets/products/103.jpg' );
insert into product values (104, 59999 , 12 , 'Smartphones' , 'Electronics', 'Apple' ,'Apple iPhone 12 128GB - Blue' , 'B000053' ,'./assets/products/104.jpg' );
insert into product values (105, 49999 , 25 , 'Smartphones' , 'Electronics', 'Apple' ,'Apple iPhone 11 64GB - Black' , 'B000054' ,'./assets/products/105.jpg' );
insert into product values (106, 41999 , 50 , 'Smart-Watches' , 'Electronics', 'Apple' ,'Apple Watch Series 7 - Blue' , 'B000055' ,'./assets/products/106.jpg' );
insert into product values (107, 29900 , 50 , 'Smart-Watches' , 'Electronics', 'Apple' ,'Apple Watch SE - White' , 'B000056' ,'./assets/products/107.jpg' );
insert into product values (108,109999 , 100 , 'Smartphones' , 'Electronics', 'Samsung Galaxy' ,'Samsung Galaxy S22 Ultra 5G - 256GB' , 'B000057' ,'./assets/products/108.jpg' );
insert into product values (109, 13499 , 100 , 'Smartphones' , 'Electronics', 'Xiaomi' ,'Redmi Note 11 White - 12GB-64GB' , 'B000058' ,'./assets/products/109.jpg' );
insert into product values (110, 69999 , 100 , 'Smartphones' , 'Electronics', 'Iqoo' ,'Iqoo 9 5G Legend - 12GB-256GB' , 'B000059' ,'./assets/products/110.jpg' );




insert into product values (111, 1299 , 300 , 'Shirts' , 'Clothes', 'Big Bazaar' ,'Checkered Cotton Full Sleeves Casual Shirt for Men' , 'B000060' ,'./assets/products/111.jpg' );
insert into product values (112, 420 , 300 , 'Shirts' , 'Clothes', 'Big Bazaar' ,'Men Cotton Solid Regular Fit Stylish Full Sleeve Shirts' , 'B000061' ,'./assets/products/112.jpg' );
insert into product values (113, 699 , 300 , 'Shirts' , 'Clothes', 'Big Bazaar' ,'Men Slim Casual Shirt' , 'B000062' ,'./assets/products/113.jpg' );
insert into product values (114, 449 , 300 , 'Shirts' , 'Clothes', 'Big Bazaar' ,'Men Solid Regular Fit Full Sleeve Cotton Casual Shirt' , 'B000063' ,'./assets/products/114.jpg' );
insert into product values (115, 437 , 300 , 'Shirts' , 'Clothes', 'Big Bazaar' ,'Men Shirt - Pink' , 'B000064' ,'./assets/products/115.jpg' );

select * from product;
